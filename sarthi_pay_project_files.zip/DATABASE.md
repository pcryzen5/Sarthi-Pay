# Database Schema Design (SQLite / Relational)

## 1. Tables Overview

### `users`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | TEXT | PRIMARY KEY | User identifier (e.g. `usr_123`) |
| `full_name` | TEXT | NOT NULL | User's full name |
| `phone_number`| TEXT | UNIQUE, NOT NULL | Mobile number |
| `preferred_lang`| TEXT | DEFAULT 'hi' | Preferred language code (`hi`, `mr`, `ta`, etc.) |
| `created_at` | DATETIME| DEFAULT CURRENT_TIMESTAMP | Record creation time |

### `accounts`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | TEXT | PRIMARY KEY | Account identifier |
| `user_id` | TEXT | FOREIGN KEY -> users(id) | Associated user |
| `bank_name` | TEXT | NOT NULL | Bank name (e.g., SBI, Bank of Baroda) |
| `account_number_mask` | TEXT | NOT NULL | Masked display number |
| `balance` | REAL | NOT NULL DEFAULT 0.0 | Available balance |
| `upi_id` | TEXT | UNIQUE | Virtual Payment Address |

### `saved_billers`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | TEXT | PRIMARY KEY | Biller record ID |
| `user_id` | TEXT | FOREIGN KEY -> users(id) | Associated user |
| `category` | TEXT | NOT NULL | `ELECTRICITY`, `GAS`, `WATER`, `MOBILE` |
| `biller_name` | TEXT | NOT NULL | e.g. Mahavitaran, Adani Gas |
| `consumer_number` | TEXT | NOT NULL | User's account number with utility |
| `last_bill_amount`| REAL | | Most recent retrieved bill |

### `transactions`
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | TEXT | PRIMARY KEY | Unique reference / token ID |
| `user_id` | TEXT | FOREIGN KEY -> users(id) | Initiator user |
| `recipient_name` | TEXT | NOT NULL | Recipient or Biller |
| `amount` | REAL | NOT NULL | Transaction value in INR |
| `intent_type` | TEXT | NOT NULL | `PAY_UTILITY`, `P2P_TRANSFER` |
| `fraud_risk_level` | TEXT | NOT NULL | `LOW`, `MEDIUM`, `HIGH` |
| `status` | TEXT | NOT NULL | `DRAFT`, `CONFIRMED`, `FAILED`, `BLOCKED` |
| `created_at` | DATETIME| DEFAULT CURRENT_TIMESTAMP | Timestamp |
