# Code Style & Development Guidelines

## 1. Backend (Python / FastAPI)
- **Typing:** Strict typing everywhere via Pydantic v2 and Python standard `typing` (`Optional`, `Union`, `Dict`).
- **Async First:** Every route and external I/O call (Gnani APIs, Hugging Face, DB) must be strictly asynchronous (`async def`, `await`).
- **Linter & Formatter:** Use `ruff` for linting and formatting. Run `ruff check .` before committing.
- **Error Handling:** Avoid generic `except Exception:`. Return typed HTTP status codes and structured error bodies.

## 2. Frontend (Next.js / TypeScript)
- **Framework:** TypeScript with Next.js App Router.
- **Styling:** Tailwind CSS with semantic naming. Keep styling accessible (e.g., `text-xl`, `font-semibold`, `min-h-[64px]` for tap targets).
- **State Management:** Keep state close to components using React hooks (`useState`, `useCallback`, `useRef` for audio buffers). Avoid heavy boilerplate state libraries.
