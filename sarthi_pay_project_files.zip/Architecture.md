# System Architecture — Sarthi Pay

## 1. System Overview
Sarthi Pay utilizes a modular, event-driven voice pipeline orchestrated via a Python (FastAPI) asynchronous server communicating with Gnani.ai cloud speech engines, an Indic reasoning LLM (Evon v3.3), and a simulated Core Banking/UPI sandbox.

```
       +---------------------------------------------------+
       |              Client (Next.js / React)             |
       |  - Web Audio Recorder (Opus/WAV 16kHz Stream)     |
       |  - Accessible Single-Action Visual State Machine  |
       |  - Synchronous Audio Player (Timbre v3.0 buffer)  |
       +-------------------------+-------------------------+
                                 |
                     WebSocket / Async HTTPS
                                 |
                                 v
       +---------------------------------------------------+
       |          FastAPI Orchestration Backend            |
       |  - Session & Context State Manager                |
       |  - Audio Buffer Chunking & Stream Relayer         |
       |  - Security & Guardrail Interceptor               |
       +-------+-------------------+-----------------+-----+
               |                   |                 |
               v                   v                 v
   +--------------------+  +---------------+  +--------------------+
   | Gnani.ai STT Engine|  |  Evon v3.3 LLM|  | Gnani Timbre TTS   |
   | (Indic Streaming)  |  | (HuggingFace) |  | (Expressive Speech)|
   +--------------------+  +---------------+  +--------------------+
               |                   |                 |
               +-------------------+-----------------+
                                   |
                                   v
             +-------------------------------------------+
             |         Mock Banking & UPI Engine         |
             |  - SQLite User Accounts & Ledgers         |
             |  - Mock BBPS (Utility Bill Fetcher)       |
             |  - Reversible Payment Token Generator     |
             +-------------------------------------------+
```

## 2. Core Service Boundaries
1. **Audio Streaming Gateway:** Ingests raw audio stream from browser Web Audio API, buffers packets, and pipes them to Gnani STT.
2. **Intent & Safety Pipeline (Evon v3.3):** Evaluates transcribed text against domain schemas, extracts entities, and scores scam risk.
3. **Transaction State Machine:** Coordinates draft creation, user confirmation state, execution against mock banking rails, and receipt payload generation.
4. **Synthesis Engine:** Converts structured system responses into empathetic, human-like vernacular audio using Gnani Timbre v3.0.
