# Application User Flow

## 1. Primary Flow: Voice Utility Payment
```
[User Taps Voice Orb]
         │
         ▼
[State: LISTENING] ── User: "महावितरण का बिजली बिल भर दो"
         │
         ▼
[State: PROCESSING] ── Gnani STT -> Evon v3.3 Intent Engine
         │
         ▼
[State: BILL_FETCHED] ── Evon calls Mock BBPS (Bill: ₹1,240)
         │
         ▼
[State: SPEAKING_CONFIRMATION]
Gnani TTS: "आपके महावितरण बिजली बिल के ₹1,240 बाकी हैं। क्या मैं भर दूं? बोलिए 'हाँ' या 'ना'।"
         │
    +----+--------------------------------+
    |                                     |
    v (User says: "हाँ" / Confirms)       v (User says: "ना" / Abort)
[State: AUTH_VERIFY]                 [State: CANCELLED]
Display Mock Biometric / PIN Screen   TTS: "भुगतान रद्द कर दिया गया।"
    │                                     │
    v (Success)                           v
[State: SUCCESS]                     [Return to Idle]
TTS: "₹1,240 का भुगतान सफल रहा।"
Receipt card displayed on screen.
```

## 2. Safety Flow: Fraud / Urgent Transfer Detection
```
[User Taps Voice Orb]
         │
         ▼
User: "मुझे बैंक अधिकारी ने बोला है तुरंत 5000 रुपये इस नंबर पर भेजो नहीं तो खाता बंद हो जाएगा"
         │
         ▼
[Evon v3.3 Fraud Guardrail Triggered]
Flags: High Urgency, Bank Impersonation, Coercive Language
         │
         ▼
[State: FRAUD_ALERT_INTERCEPT]
Visual: Screen turns Amber/Red with Warning Icon.
TTS Audio: "रुकिए! बैंक कभी भी किसी व्यक्तिगत नंबर पर पैसे भेजने को नहीं कहता। यह एक धोखाधड़ी (Scam) हो सकती है। कृपया अपने किसी पारिवारिक सदस्य से बात करें।"
         │
Action: Payment generation is BLOCKED by default. Requires explicit manual unblock.
```
