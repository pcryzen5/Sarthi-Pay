# Technical Requirements Document (TRD)

## 1. Technical Stack
- **Frontend:** Next.js (App Router), React 19, Tailwind CSS, Lucide Icons, Web Audio API.
- **Backend:** Python 3.11+, FastAPI, Uvicorn, Pydantic v2, HTTPX (Async HTTP).
- **Speech & AI Services:**
  - Speech-to-Text: Gnani.ai Streaming STT REST/WebSocket API.
  - Text-to-Speech: Gnani.ai Timbre v3.0 Expressive Indic TTS API.
  - Language Model: Evon v3.3 via Hugging Face Inference API / Local vLLM instance.
- **Database:** SQLite (WAL mode) with SQLAlchemy Async ORM.
- **Hosting/Runtime:** Node.js 20+, Docker containerized backend.

## 2. Interface Contracts
- **Audio Specifications:**
  - Input: 16,000 Hz, 16-bit Mono PCM or Opus container.
  - Output: 24,000 Hz / 44,100 Hz MP3/WAV streaming audio stream.
- **Latency Targets:**
  - STT First Chunk Transcription: < 400ms.
  - Evon v3.3 TTFT (Time To First Token): < 600ms.
  - TTS Synthesis & Audio Playback Start: < 500ms.
  - Full Turnaround Budget: <= 2000ms.

## 3. Resilience & Fallback Handling
- **Network Degradation:** Fallback to batch REST audio uploads if WebSocket stream drops.
- **Ambiguous Audio:** If transcription confidence is below 0.65, trigger a clarifying prompt asking the user to repeat the amount or name.
- **Biller API Down:** Graceful voice notification indicating utility provider downtime without failing user transaction context.
