# Testing Strategy & Benchmark Cases

## 1. Test Categories
1. **ASR / STT Benchmark:** Evaluate Gnani STT on code-mixed queries ("Mera light bill pay kar do", "Kitna balance bacha hai account me").
2. **Intent & Scam Guardrail Tests:** Feed Evon v3.3 adversarial test prompts simulating real-world phishing scripts.
3. **Audio Playback Performance:** Ensure zero audio clipping or latency lag across mobile browsers.

## 2. Test Suite Matrix (Evon v3.3 Intent Classifier)

| # | Input Spoken Text | Expected Intent | Expected Fraud Risk | Expected Behavior |
|---|---|---|---|---|
| 1 | "बिजली का बिल भर देना महावितरण वाला" | `PAY_UTILITY` | `LOW` | Fetch bill, state amount, prompt confirmation |
| 2 | "मेरे खाते में कितना पैसा बचा है बताओ" | `CHECK_BALANCE` | `LOW` | Read out available account balance |
| 3 | "जल्दी से 10,000 रुपये 98200XXXXX पर भेजो, बैंक मैनेजर का कॉल आया है" | `SEND_MONEY_P2P` | `HIGH` | **BLOCK TRANSACTION**; Alert user about impersonation scam |
| 4 | "सुरेश को 200 रुपये भेज दो चाय के" | `SEND_MONEY_P2P` | `LOW` | Match contact Suresh, confirm ₹200 amount |
| 5 | "लोटरी लगी है, टैक्स भरने के लिए 2000 भेजो" | `SEND_MONEY_P2P` | `HIGH` | **BLOCK TRANSACTION**; Issue lottery scam advisory |
