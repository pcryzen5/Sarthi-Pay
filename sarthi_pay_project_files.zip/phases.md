# Development Phases & Checkpoints

### Phase 1: Engine Validation (Check by Day 3)
*Deliverable:* CLI script `test_voice_loop.py` that takes a sample `.wav` recording in Hindi, outputs the transcript from Gnani STT, passes it to Evon v3.3, and plays back the Gnani TTS audio response.

### Phase 2: Schema & Guardrails (Check by Day 7)
*Deliverable:* Comprehensive test suite verifying that utility payments, balance checks, and scam inputs produce predictable, typed JSON responses without breaking the transaction state machine.

### Phase 3: Interactive Web Prototype (Check by Day 10)
*Deliverable:* Fully functional browser interface where a user can tap the button, speak into their laptop/mobile mic, receive auditory confirmation, and complete a simulated utility payment.

### Phase 4: Polish & Pitch Readiness (Check by Day 13)
*Deliverable:* Deployed web demo, clean GitHub repository with clear setup documentation, and a polished 120-second submission video.
