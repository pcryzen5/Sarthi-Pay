# Security, Safety & Guardrails Specification

## 1. Voice Banking Scam Interceptor
Sarthi Pay embeds guardrails directly into Evon v3.3's inference schema:
- **Urgency Detection:** Phrases indicating immediate harm, bank account closure, or power cut within minutes are automatically routed to a `HIGH` risk rating.
- **Unverified VPA Interception:** Any voice request requesting transfer to an unfamiliar 10-digit number not present in `saved_contacts` triggers a mandatory secondary auditory warning stating: *"यह नंबर आपके संपर्कों में नहीं है। क्या आप पूरी तरह से आश्वस्त हैं?"*
- **Absolute Hard Limit:** Single-turn voice transactions cannot exceed ₹10,000 without manual multi-factor PIN override.

## 2. Data Privacy & Tokenization
- **No Raw Voice Storage:** User audio recordings are processed in memory and discarded immediately after transcription; raw biometric voice data is never persisted on disk.
- **PII Scrubbing:** Account numbers are masked on all UI cards and logs (`******4012`).
- **No Direct Execution on Speech:** Spoken words create a *draft* state only. Financial movement is blocked until step 2 confirmation is received.
