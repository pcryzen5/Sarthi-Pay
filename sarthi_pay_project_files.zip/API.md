# API Specifications

## 1. Speech & Voice Streaming

### `POST /api/v1/voice/process-command`
Accepts multipart audio file or raw payload, transcribes via Gnani STT, reasons via Evon v3.3, and returns structured action + synthesized TTS audio stream.

#### Request (Multipart Form):
- `audio`: Audio file binary (wav/webm/opus)
- `session_id`: UUID string
- `user_id`: string

#### Response (JSON):
```json
{
  "transcription": "बिजली का बिल भर दो",
  "intent": "PAY_UTILITY",
  "entities": {
    "utility_type": "ELECTRICITY",
    "biller_name": "Mahavitaran",
    "amount": 1240.00
  },
  "fraud_check": {
    "is_flagged": false,
    "risk_level": "LOW",
    "reason": null
  },
  "confirmation_message": "आपके महावितरण बिजली बिल के ₹1,240 बाकी हैं। क्या मैं इसे भर दूं?",
  "audio_base64": "UklGRi...",
  "requires_confirmation": true,
  "transaction_token": "txn_draft_89412a"
}
```

---

## 2. Transaction Management

### `POST /api/v1/transaction/confirm`
Confirms and settles a drafted transaction token.

#### Request:
```json
{
  "transaction_token": "txn_draft_89412a",
  "user_confirmation": "CONFIRMED",
  "auth_method": "BIOMETRIC_PASS"
}
```

#### Response:
```json
{
  "status": "SUCCESS",
  "reference_id": "UPI/20261102/981240124",
  "receipt_message": "₹1,240 का भुगतान सफल रहा।",
  "audio_base64": "UklGR..."
}
```

---

## 3. Account & Balance

### `GET /api/v1/account/{user_id}/balance`
Returns balance and linked bank accounts.

#### Response:
```json
{
  "user_id": "usr_9921",
  "primary_account": {
    "bank_name": "State Bank of India",
    "account_mask": "******3412",
    "balance": 24850.50
  }
}
```
