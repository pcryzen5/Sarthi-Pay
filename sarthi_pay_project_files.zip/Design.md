# Design & UX Guidelines — Sarthi Pay

## 1. Visual Hierarchy & Philosophy
Designed strictly under the **Elderly-First Accessible Interaction Principles**:
- **Zero Ambiguity:** A single primary action at any given stage.
- **High Visual Contrast:** Dark Charcoal (`#121212`) on Warm Cream/Ivory (`#FAF7F2`) with High-Contrast Green (`#15803D`) and Crimson Alert (`#B91C1C`).
- **No Decorative Elements:** Eliminates marketing banners, carousels, or gamified reward badges.

## 2. Screen Anatomy
1. **Top Status Bar:** Large text showing current mode: "सुन रहे हैं..." (Listening), "सोच रहे हैं..." (Thinking), "बोल रहे हैं..." (Speaking).
2. **Central Voice Orb:** 160px diameter circular button with smooth pulse rings reacting to mic decibels.
3. **Live Captions / Confirmation Card:** 
   - User transcription displayed in large bold type (min 22px).
   - System response card with clear breakdown:
     - **Biller / Recipient:** e.g., महावितरण (Mahavitaran)
     - **Amount:** ₹1,450
     - **Account:** Union Bank (**4091)
4. **Emergency Abort Strip:** Persistent bottom red button: "रद्द करें / Cancel" for immediate fail-safe exits.

## 3. Typography & Sound Design
- **Font Stack:** Noto Sans Devanagari, Inter, system-ui.
- **Audio Feedback Cues:**
  - Soft chime on mic open.
  - Distinct double chime on transaction complete.
  - Low-frequency alert tone on fraud warning trigger.
