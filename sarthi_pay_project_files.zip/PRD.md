# Product Requirement Document (PRD) — Sarthi Pay

## 1. Executive Summary
Sarthi Pay is an accessible, voice-first financial assistant tailored for senior citizens in India. It bridges the digital divide in digital banking and UPI payments by replacing dense touchscreens and confusing UI hierarchies with natural spoken vernacular interactions, automated scam guardrails, and clear auditory feedback.

## 2. Problem Statement
- **Cognitive & Visual Friction:** Modern UPI apps (GPay, PhonePe, Paytm) are cluttered with ads, reward scratch cards, complex dropdown menus, and small typography.
- **Vernacular Divide:** Most interfaces assume English/Hindi literacy with technical vocabulary, failing users who speak colloquial, dialect-heavy, or code-mixed Indic languages.
- **Vulnerability to Financial Fraud:** Seniors are disproportionately targeted by urgency-driven social engineering (e.g., fake KYC expiration, utility disconnection threats, lottery scams).

## 3. Goals & Success Metrics
- **Zero-Typing Task Completion:** Enable balance inquiries and utility bill payments purely through voice.
- **Low-Latency Conversational Turnaround:** End-to-end voice round-trip (speech input to synthesized spoken response) in under 2.5 seconds.
- **Fraud Mitigation:** 100% interception of known urgency and scam trigger patterns before generating payment payloads.
- **Accessibility:** Large-touch targets, minimum 20px typography, high contrast (WCAG AAA), and real-time live captions.

## 4. User Personas
- **Ramesh Uncle (Age 68, Retired Teacher):** Speaks Hindi and conversational English. Needs to pay electricity and water bills without depending on his children. Worries about pressing the wrong button.
- **Kamala Bai (Age 64, Homemaker):** Primarily speaks Hindi/Marathi dialect. Comfortable with voice notes on messaging apps, but intimidated by multi-step PIN entries and mobile banking apps.

## 5. Scope & Feature List
- **Voice-Driven Core Workflows:**
  - Balance inquiry across linked accounts.
  - P2P transfers to pre-saved family and trusted contacts.
  - Utility bill fetch & pay (Electricity, Gas, Water, Mobile Recharge).
- **Proactive Scam Prevention:** LLM-based intent parsing that flags urgency keywords ("तुरंत भेजो", "खाता ब्लॉक") and warns users with high-priority audio prompts.
- **Two-Step Voice Confirmation:** Auditory playback of recipient name, institution, and amount with an explicit verbal "हाँ / Confirm" requirement before token creation.
- **Non-Functional Requirements:**
  - Works smoothly on 4G mobile web browsers.
  - Fallback visual buttons if background noise prevents accurate audio capture.
