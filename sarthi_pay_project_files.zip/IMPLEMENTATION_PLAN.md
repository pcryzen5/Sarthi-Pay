# Implementation Plan & Milestones

## Sprint 1: Foundation & API Scaffolding (Days 1–3)
- [ ] Initialize repository structure (frontend/ and backend/).
- [ ] Set up FastAPI project with CORS, environment configuration, and logging.
- [ ] Implement client-side Web Audio recorder capturing 16kHz audio chunks.
- [ ] Connect Gnani.ai STT streaming client and test Devanagari Hindi transcription.
- [ ] Connect Gnani.ai Timbre v3.0 TTS endpoint for audio synthesis.

## Sprint 2: Evon v3.3 Reasoning & Mock Banking (Days 4–7)
- [ ] Integrate Evon v3.3 client via Hugging Face Inference API.
- [ ] Define system prompt and Pydantic schema for structured intent extraction.
- [ ] Implement SQLite mock banking ledger (accounts, balances, billers, transaction history).
- [ ] Build Scam and Urgency detection heuristics in the LLM post-processor.
- [ ] Write integration test verifying Audio -> STT -> Evon -> TTS round-trip.

## Sprint 3: Accessible Frontend & Audio Pipeline (Days 8–10)
- [ ] Build high-contrast, large-button UI with Tailwind CSS.
- [ ] Implement audio playback queue handling chunked responses smoothly without pops/glitches.
- [ ] Add dual-language live captions on screen.
- [ ] Build payment confirmation card and pin authentication modal.

## Sprint 4: Hardening, Benchmarking & Presentation (Days 11–14)
- [ ] Measure and optimize end-to-end latency to < 2.5 seconds.
- [ ] Conduct end-to-end testing with varied accents and noise profiles.
- [ ] Add pre-recorded demo fallback scenarios for live judging reliability.
- [ ] Film 2-minute video walkthrough showcasing senior-friendly usability and scam interception.
